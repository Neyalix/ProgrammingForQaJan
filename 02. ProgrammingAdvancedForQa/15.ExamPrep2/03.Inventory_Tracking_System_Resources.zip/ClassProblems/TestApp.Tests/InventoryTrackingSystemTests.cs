using System;
using System.Text;
using System.Linq;
using NUnit.Framework;
using System.Collections.Generic;

namespace TestApp.Tests;

[TestFixture]
public class InventoryTrackingSystemTests
{
    [Test]
    public void Test_Constructor_CheckInitialEmptyItemCollectionAndCount()
    {
        // TODO: finish the test
    }

    [Test]
    public void Test_AddItem_ValidItemName_AddNewItem()
    {
        // TODO: finish the test
    }

    [Test]
    public void Test_AddItem_NullOrEmptyItemName_ThrowsArgumentException()
    {
        // TODO: finish the test
    }

    [Test]
    public void Test_RemoveItem_ValidItemName_RemoveFirstItemName()
    {
        // TODO: finish the test
    }

    [Test]
    public void Test_RemoveItem_NullOrEmptyItemName_ThrowsArgumentException()
    {
        // TODO: finish the test
    }

    [Test]
    public void Test_GetAllItems_AddedAndRemovedItems_ReturnsExpectedItemCollection()
    {
        // TODO: finish the test
    }
}
